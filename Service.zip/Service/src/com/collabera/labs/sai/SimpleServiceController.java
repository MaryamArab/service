package com.collabera.labs.sai;

     import java.io.File;
import java.io.IOException;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
//import android.hardware.Sensor;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.view.SurfaceHolder;
//import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;
//*******************
//import java.io.File;
import java.io.FileWriter;
//import java.io.IOException;
import java.io.PrintWriter;
//***********

public class SimpleServiceController extends Activity implements SurfaceHolder.Callback {

	   MediaRecorder mediaRecorder;
	   SurfaceHolder surfaceHolder;
	   boolean recording;
	   WakeLock wl;

	   String name="test";
	   Intent sensor =null;
	   long timestamp=0;
	   
	   //*********************
		int gpsCount;
		float gpsData [][] = new float[180000][5];
		long gpstimestamp;
		boolean logGPS = false; 
	   //*********************
		
	   @SuppressWarnings("deprecation")
	@Override
		protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        
	        recording = false;
	  	    
	        String fSaveName = Environment.getExternalStorageDirectory().toString();
			PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
			wl = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "My Drive");
				     
	        File folder = new File(fSaveName,"DriveCapture");
			folder.mkdir();
	        
	        mediaRecorder = new MediaRecorder();
	        /////
	     //   Camera mCamera = mCamera = getCameraInstance();
	        // adjust the camera the way you need
	     //   mCamera.setDisplayOrientation(90);
		   //////////////////////////////////////////
	        setContentView(R.layout.main);
	            
	        SurfaceView myVideoView = (SurfaceView)findViewById(R.id.videoView);
	        surfaceHolder = myVideoView.getHolder();
	        surfaceHolder.addCallback(this);
	        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);	        
	        
	        Button start = (Button)findViewById(R.id.serviceButton);
	        Button stop = (Button)findViewById(R.id.cancelButton);
	        // ********************************************************
	        /* Use the LocationManager class to obtain GPS locations */
	        LocationManager mlocManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

	        LocationListener mlocListener = new MyLocationListener();
	        mlocManager.requestLocationUpdates( LocationManager.GPS_PROVIDER, 0, 0, mlocListener);  
	        Toast.makeText( getApplicationContext(), "GPS Working", Toast.LENGTH_SHORT).show();
	        // ********************************************************
	        start.setOnClickListener(startListener);
	        stop.setOnClickListener(stopListener);
	        wl.acquire();
	   }
	   
	   @Override
	   protected void onStop() {
			// TODO Auto-generated method stub
			super.onStop();
			if(wl.isHeld())
				wl.release();
			
			
	   }
       private OnClickListener startListener = new OnClickListener() {
       	public void onClick(View v){
       		//name = nametxt.getText().toString();
       		//if(name==null||name.length()==0){
       		//	Toast.makeText(getApplicationContext(), "Give a name", Toast.LENGTH_SHORT).show();
       		//	return;
       		//}
       
       		
     
       		if(recording==false){
       			sensor = new Intent(SimpleServiceController.this,SimpleService.class);
        		sensor.putExtra("filename", timestamp+"");
        		startService(sensor);
        		 
       			mediaRecorder.start();
       		    recording = true;
       		    logGPS = true; 
       		   }
       	}	        	
       };
       
       private OnClickListener stopListener = new OnClickListener() {
          	public void onClick(View v){
          		Toast.makeText(getApplicationContext(), "-- STOOOOOOOP --", Toast.LENGTH_SHORT).show();
          		if(recording==false)return;
          		
          		if(recording){
          			   stopService(sensor);
            		   mediaRecorder.stop();
            		 //  mediaRecorder.release();
            		   recording=false;
            		   logGPS = false; 
            		   
           	  		
           	  		String file_name="";
           	  		//file_name = "gpsFileName";//intent.getStringExtra("filename");
           	  		
           	  		PrintWriter captureFile1=null; 

           	  		long fileTimestamp = System.currentTimeMillis();
           	  		String gspFN = String.valueOf(fileTimestamp);
           	  		file_name=file_name+gspFN;
           	  		
           	  		File captureAccFile = new File( "/sdcard/DriveCapture", file_name+"GPSData.csv" );

           	  		try{
           	  		captureFile1 = new PrintWriter( new FileWriter( captureAccFile, false ) );
           	  		
           	  		for(int i=0;i<gpsCount;i++)
           	  		   captureFile1.println(gpsData[i][0]+","+gpsData[i][1]+","+gpsData[i][2]+","+gpsData[i][3]+","+gpsData[i][4]);
           	  		
           	  	   
           	  		Toast.makeText(getApplicationContext(), "-- GPS Files writen --", Toast.LENGTH_SHORT).show();
           	  		
           	  		}   
           	  		catch(IOException e){
           	  			Log.i("SensorService: ", e.getMessage());
           	  		}
           	  		finally{
           	  			captureFile1.close();
           	  		}
            	}
          	}	        	
          };
          
          private void initMediaRecorder(){
        	  mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC); 
        	  mediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA); 
        	  mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT); 
        	  
        	  // Specify the audio and video encoding 
        	  mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT); 
        	  mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.DEFAULT); 
        	  // Specify the output file 
        	  mediaRecorder.setOrientationHint(90);
        	  mediaRecorder.setMaxDuration(3600000);
        	  //mediaRecorder.setOutputFile("/sdcard/DriveCapture/test.mp4"); 
        	  //mediaRecorder.setVideoFrameRate(10);
        	  timestamp = System.currentTimeMillis();
        	  mediaRecorder.setOutputFile( Environment.getExternalStorageDirectory().getPath()+"/DriveCapture/"+timestamp+".mp4");
        	    
        	  } 
          
          private void prepareMediaRecorder(){
        	  mediaRecorder.setPreviewDisplay(surfaceHolder.getSurface());
        	  try {
        	   mediaRecorder.prepare();
        	  } catch (IllegalStateException e) {
        	   // TODO Auto-generated catch block
        	   e.printStackTrace();
        	  } catch (IOException e) {
        	   // TODO Auto-generated catch block
        	   e.printStackTrace();
        	  }
        	 }

		@Override
		public void surfaceCreated(SurfaceHolder holder) {
			// TODO Auto-generated method stub
			initMediaRecorder();
			prepareMediaRecorder();
		}

		@Override
		public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void surfaceDestroyed(SurfaceHolder holder) {
			// TODO Auto-generated method stub
			
		}
		
/* ******************************  */
	    /* Class My Location Listener */
	    public class MyLocationListener implements LocationListener
	    {

	      @Override
	      public void onLocationChanged(Location loc)
	      {

	        loc.getLatitude();
	        loc.getLongitude();
	        loc.getAltitude();
	        loc.getAccuracy();
	        loc.getSpeed();
	        loc.getTime();

	      /*  String Text = "My current location is: " +
	        "Latitud = " + loc.getLatitude() +
	        "Longitud = " + loc.getLongitude() +
	        "Altitude = " + loc.getAltitude();
	      */
	        //*********************
	        if (logGPS== true )
	        { 
		        gpsData[gpsCount][0]=(float) loc.getLatitude();
		        gpsData[gpsCount][1]=(float) loc.getLongitude();
		        gpsData[gpsCount][2]=(float) loc.getAltitude();
		        gpsData[gpsCount][3]=(float) loc.getSpeed();
		        gpsData[gpsCount][4]= (float)System.nanoTime();//   .currentTimeMillis();//loc.getTime();
		        gpstimestamp= loc.getTime(); 
				gpsCount++;
				//****************************
				String Text =""; 
		        Text = "[" + loc.getTime() + "]  ["+ loc.getSpeed()+"]";// +   gpsData[gpsCount-1][4];
		        Toast.makeText( getApplicationContext(), Text, Toast.LENGTH_SHORT).show();
	        }
	      }

	      @Override
	      public void onProviderDisabled(String provider)
	      {
	        Toast.makeText( getApplicationContext(), "Gps Disabled", Toast.LENGTH_SHORT ).show();
	      }

	      @Override
	      public void onProviderEnabled(String provider)
	      {
	        Toast.makeText( getApplicationContext(), "Gps Enabled", Toast.LENGTH_SHORT).show();
	      }

	      @Override
	      public void onStatusChanged(String provider, int status, Bundle extras)
	      {
	    	  Toast.makeText( getApplicationContext(), "Status changed " , Toast.LENGTH_SHORT).show();

	      }
	      
      
	    }//Class listener 

	  	@Override
	  	public void onDestroy() {
	  		/*super.onDestroy();
	  		
	  		String file_name="";
	  		//file_name = "gpsFileName";//intent.getStringExtra("filename");
	  		
	  		PrintWriter captureFile1=null; 

	  		long fileTimestamp = System.currentTimeMillis();
	  		String gspFN = String.valueOf(fileTimestamp);
	  		file_name=file_name+gspFN;
	  		
	  		File captureAccFile = new File( "/sdcard/DriveCapture", file_name+"GPSData.csv" );

	  		try{
	  		captureFile1 = new PrintWriter( new FileWriter( captureAccFile, false ) );
	  		
	  		for(int i=0;i<gpsCount;i++)
	  		   captureFile1.println(gpsData[i][0]+","+gpsData[i][1]+","+gpsData[i][2]+","+gpsData[i][3]+","+gpsData[i][4]);
	  		
	  	   
	  	   // Toast.makeText(this,"GPS written .. .. ", Toast.LENGTH_LONG).show();
	  		
	  		}   
	  		catch(IOException e){
	  			Log.i("SensorService: ", e.getMessage());
	  		}
	  		finally{
	  			captureFile1.close();
	  		}*/
	  		
	  			  		
	  	}//on Destroy	    
		
}
